[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/tamilvetri/TGUPLOADER)

#### PENDING WORKS

* Permanent Thumbnail Support
* Time Gap 
* Callback Things Update { CODE }
