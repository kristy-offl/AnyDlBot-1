

import os
import logging
import pyrogram

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

logging.getLogger("pyrogram").setLevel(logging.WARNING)

if bool(os.environ.get("WEBHOOK", False)):

    from sample_config import Config
else:
    from config import Config

from translation import Translation
from pyrogram import Client, filters
from plugins.dl_button import ddl_call_back
from plugins.youtube_dl_button import youtube_dl_call_back
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton



@Client.on_callback_query()
async def button(bot, update):


      if    "|"    in update.data:
                   await youtube_dl_call_back(bot, update)



      if    "="    in update.data:
                   await ddl_call_back(bot, update)




      if  'close'  in update.data:
                   await update.message.delete()
