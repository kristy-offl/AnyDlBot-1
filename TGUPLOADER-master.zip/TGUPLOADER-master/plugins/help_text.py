import os
import sqlite3
import logging
import pyrogram

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

logging.getLogger("pyrogram").setLevel(logging.WARNING)

if bool(os.environ.get("WEBHOOK", False)):

    from sample_config import Config
else:
    from config import Config

from translation import Translation
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton




@Client.on_message(filters.command(["start"]))
async def start(bot, update):
      await bot.send_message(
            text=Translation.START_TEXT.format(update.from_user.first_name),
            chat_id=update.chat.id,
            parse_mode="html",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup( [ [ InlineKeyboardButton('support channel', url='_'),
                                                   InlineKeyboardButton('support group',url='_') ],
                                                 [ InlineKeyboardButton('✖️ Close ✖️', url='_') ] ] ) )







@Client.on_message(filters.command(["upgrade"]))
async def upgrade(bot, update):
      await bot.send_message(
            chat_id=update.chat.id,
            text=Translation.UPGRADE_TEXT,
            parse_mode="html",
            disable_web_page_preview=True,
            reply_to_message_id=update.message_id,
            reply_markup=InlineKeyboardMarkup( [ [ InlineKeyboardButton('✖️ Close ✖️',  callback_data='close') ] ] ) )



@Client.on_message(filters.command(["help"]))	
async def help(bot, update):
      await bot.send_message(	
            chat_id=update.chat.id,	
            text=Translation.HELP_TEXT,	
            parse_mode="html",	
            disable_web_page_preview=True,	
            reply_to_message_id=update.message_id,	
            reply_markup=InlineKeyboardMarkup( [ [ InlineKeyboardButton('✖️ Close ✖️',  callback_data='close') ] ] ) )	




@Client.on_message(filters.command(["about"]))	
async def about(bot, update):
      await bot.send_message(	
            chat_id=update.chat.id,	
            text=Translation.ABOUT_TEXT,	
            parse_mode="html",	
            disable_web_page_preview=True,	
            reply_to_message_id=update.message_id,	
            reply_markup=InlineKeyboardMarkup( [ [ InlineKeyboardButton('✖️ Close ✖️',  callback_data='close') ] ] ) )	
